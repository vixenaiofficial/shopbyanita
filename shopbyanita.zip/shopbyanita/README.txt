Femme Vibes website (deploy-ready)

Deploy on Vercel (run in this folder, on your computer):
  npm i -g vercel
  vercel login
  vercel --prod --name shopbyanita

Your site will be live at https://shopbyanita.vercel.app (or the URL Vercel shows).
